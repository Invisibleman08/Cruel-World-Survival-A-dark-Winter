-- Colors --

_G.colors = {
  white = 0xFFFFFF,
  orange = 0xFF9933,
  magenta = 0xCC33FF,
  lightBlue = 0x6699FF,
  yellow = 0xFFFF00,
  lime = 0x66FF33,
  pink = 0xFF3399,
  gray = 0x888888,
  silver = 0xCCCCCC,
  cyan = 0x33CCCC,
  purple = 0xCC00FF,
  blue = 0x3333FF,
  brown = 0x996633,
  green = 0x00cc00,
  red = 0xFF0000,
  black = 0x000000
}
