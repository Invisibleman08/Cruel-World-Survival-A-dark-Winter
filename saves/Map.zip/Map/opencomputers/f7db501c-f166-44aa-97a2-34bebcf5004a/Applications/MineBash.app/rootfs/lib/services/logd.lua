-- Was initially intended to be more, but functionality added to the kernel API has made this simpler. --

kernel.hideLogs()
