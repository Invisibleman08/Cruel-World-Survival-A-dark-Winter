# open-kernel
A simple operating system for OpenComputers.

As of version 0.2.0 (I think), I am proud to say that Open Kernel uses a mere 80KB of RAM, compared to OpenOS' 170KB, on a Tier 1 stick of memory!

Takes 24.5K of disk space when you use the installer, about 40K when you `git clone`. I recommend using the installer.

Now with external FS / floppy support!

I need to make sure GitHub doesn't overwrite this again....

Finally has an installer! It's located at https://pastebin.com/BxmYj0wJ. Note that it should work in OpenOS *and* Open Kernel.
